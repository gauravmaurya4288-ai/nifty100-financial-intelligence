import sqlite3
import os

# Create db folder if it doesn't exist
os.makedirs("db", exist_ok=True)

# Connect to SQLite database
conn = sqlite3.connect("db/nifty100.db")
cursor = conn.cursor()

# Enable Foreign Keys
cursor.execute("PRAGMA foreign_keys = ON")

# -----------------------------
# Companies
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS companies (

    company_id TEXT PRIMARY KEY,
    company_logo TEXT,
    company_name TEXT,
    chart_link TEXT,
    about_company TEXT,
    website TEXT,
    nse_profile TEXT,
    bse_profile TEXT,
    face_value REAL,
    book_value REAL,
    roce_percentage REAL,
    roe_percentage REAL

);
""")

# -----------------------------
# Profit & Loss
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS profit_loss (

    company_id TEXT,
    year TEXT,

    sales REAL,
    expenses REAL,
    operating_profit REAL,
    opm_percentage REAL,
    other_income REAL,
    interest REAL,
    depreciation REAL,
    profit_before_tax REAL,
    tax_percentage REAL,
    net_profit REAL,
    eps REAL,
    dividend_payout REAL,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Balance Sheet
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS balance_sheet (

    company_id TEXT,
    year TEXT,

    equity_capital REAL,
    reserves REAL,
    borrowings REAL,
    other_liabilities REAL,
    total_liabilities REAL,
    fixed_assets REAL,
    cwip REAL,
    investments REAL,
    other_asset REAL,
    total_assets REAL,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Cash Flow
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS cash_flow (

    company_id TEXT,
    year TEXT,

    operating_activity REAL,
    investing_activity REAL,
    financing_activity REAL,
    net_cash_flow REAL,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Stock Prices
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS stock_prices (

    company_id TEXT,
    date TEXT,

    open_price REAL,
    high_price REAL,
    low_price REAL,
    close_price REAL,
    volume REAL,
    adjusted_close REAL,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Market Cap
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS market_cap (

    company_id TEXT,
    year TEXT,

    market_cap_crore REAL,
    enterprise_value_crore REAL,
    pe_ratio REAL,
    pb_ratio REAL,
    ev_ebitda REAL,
    dividend_yield_pct REAL,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Ratios
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS ratios (

    company_id TEXT,
    year TEXT,

    net_profit_margin_pct REAL,
    operating_profit_margin_pct REAL,
    return_on_equity_pct REAL,
    debt_to_equity REAL,
    interest_coverage REAL,
    asset_turnover REAL,
    free_cash_flow_cr REAL,
    capex_cr REAL,
    earnings_per_share REAL,
    book_value_per_share REAL,
    dividend_payout_ratio_pct REAL,
    total_debt_cr REAL,
    cash_from_operations_cr REAL,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Financial Ratios
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS financial_ratios (

    company_id TEXT,
    year TEXT,

    net_profit_margin_pct REAL,
    operating_profit_margin_pct REAL,
    return_on_equity_pct REAL,

    debt_to_equity REAL,
    interest_coverage REAL,
    asset_turnover REAL,

    free_cash_flow_cr REAL,
    capex_cr REAL,

    earnings_per_share REAL,
    book_value_per_share REAL,

    dividend_payout_ratio_pct REAL,

    total_debt_cr REAL,
    cash_from_operations_cr REAL,

    revenue_cagr_5yr REAL,
    pat_cagr_5yr REAL,
    eps_cagr_5yr REAL,

    composite_quality_score REAL,

    PRIMARY KEY(company_id, year),

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Pros & Cons
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS pros_cons (

    company_id TEXT,
    pros TEXT,
    cons TEXT,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Sectors
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS sectors (

    company_id TEXT,
    broad_sector TEXT,
    sub_sector TEXT,
    index_weight_pct REAL,
    market_cap_category TEXT,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Analysis
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS analysis (

    company_id TEXT,
    compounded_sales_growth REAL,
    compounded_profit_growth REAL,
    stock_price_cagr REAL,
    roe REAL,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Peer Groups
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS peer_groups (

    peer_group_name TEXT,
    company_id TEXT,
    is_benchmark INTEGER,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

# -----------------------------
# Documents
# -----------------------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS documents (

    company_id TEXT,
    year TEXT,
    annual_report TEXT,

    FOREIGN KEY(company_id)
    REFERENCES companies(company_id)

);
""")

conn.commit()

print("=" * 60)
print("NIFTY100 DATABASE CREATED SUCCESSFULLY")
print("=" * 60)

# Display all tables
tables = cursor.execute("""
SELECT name
FROM sqlite_master
WHERE type='table'
ORDER BY name;
""").fetchall()

print("\nTables Created:\n")

for table in tables:
    print(table[0])

conn.close()