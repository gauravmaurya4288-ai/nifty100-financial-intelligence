import sqlite3
import pandas as pd

DB_PATH = "db/nifty100.db"

conn = sqlite3.connect(DB_PATH)

print("=" * 70)
print("DATABASE INFORMATION")
print("=" * 70)

# -------------------------------------------------
# List all tables
# -------------------------------------------------

tables = pd.read_sql(
    """
    SELECT name
    FROM sqlite_master
    WHERE type='table'
    ORDER BY name
    """,
    conn
)

print("\nTables:")
print(tables)

# -------------------------------------------------
# Row count of every table
# -------------------------------------------------

print("\n" + "=" * 70)
print("ROW COUNTS")
print("=" * 70)

for table in tables["name"]:

    try:

        count = pd.read_sql(
            f"SELECT COUNT(*) AS rows FROM {table}",
            conn
        )

        print(f"{table:<25} {count.iloc[0,0]}")

    except Exception as e:

        print(table, e)

# -------------------------------------------------
# financial_ratios schema
# -------------------------------------------------

print("\n" + "=" * 70)
print("financial_ratios SCHEMA")
print("=" * 70)

schema = pd.read_sql(
    """
    PRAGMA table_info(financial_ratios)
    """,
    conn
)

print(schema)

# -------------------------------------------------
# First 10 rows
# -------------------------------------------------

print("\n" + "=" * 70)
print("FIRST 10 ROWS")
print("=" * 70)

sample = pd.read_sql(
    """
    SELECT *
    FROM financial_ratios
    LIMIT 10
    """,
    conn
)

print(sample)

# -------------------------------------------------
# Check important columns
# -------------------------------------------------

print("\n" + "=" * 70)
print("IMPORTANT COLUMNS")
print("=" * 70)

important = [

    "market_cap_crore",
    "pe_ratio",
    "pb_ratio",
    "ev_ebitda",
    "dividend_yield_pct",

    "revenue_cagr_5yr",
    "pat_cagr_5yr",
    "eps_cagr_5yr",

    "composite_quality_score"

]

for col in important:

    if col in sample.columns:

        total = pd.read_sql(

            f"""
            SELECT COUNT({col}) AS filled
            FROM financial_ratios
            """,

            conn

        )

        print(f"{col:<30} {total.iloc[0,0]}")

    else:

        print(f"{col:<30} NOT FOUND")

# -------------------------------------------------
# Save table to Excel
# -------------------------------------------------

df = pd.read_sql(
    "SELECT * FROM financial_ratios",
    conn
)

df.to_excel(
    "output/financial_ratios.xlsx",
    index=False
)

print("\nExcel saved to:")
print("output/financial_ratios.xlsx")

conn.close()

print("\nDone.")