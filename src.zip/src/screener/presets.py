import sqlite3
import pandas as pd

DB_PATH = "db/nifty100.db"

conn = sqlite3.connect(DB_PATH)

financial = pd.read_sql(
    "SELECT * FROM financial_ratios",
    conn
)

market = pd.read_sql(
    "SELECT * FROM market_cap",
    conn
)

sector = pd.read_sql(
    "SELECT * FROM sectors",
    conn
)

df = (
    financial
    .merge(
        market,
        on=["company_id", "year"],
        how="left"
    )
    .merge(
        sector,
        on="company_id",
        how="left"
    )
)

quality = df[

    (df.return_on_equity_pct > 15)

    &

    (
        (df.debt_to_equity < 1)

        |

        (df.broad_sector == "Financials")

    )

    &

    (df.free_cash_flow_cr > 0)

    &

    (df.revenue_cagr_5yr > 10)

]

quality = quality.sort_values(
    "composite_quality_score",
    ascending=False
)

value = df[

    (df.pe_ratio < 20)

    &

    (df.pb_ratio < 3)

    &

    (df.debt_to_equity < 2)

    &

    (df.dividend_yield_pct > 1)

]

value = value.sort_values(
    "composite_quality_score",
    ascending=False
)


growth = df[

    (df.pat_cagr_5yr > 20)

    &

    (df.revenue_cagr_5yr > 15)

    &

    (df.debt_to_equity < 2)

]

dividend = df[

    (df.dividend_yield_pct > 2)

    &

    (df.dividend_payout_ratio_pct < 80)

    &

    (df.free_cash_flow_cr > 0)

]

bluechip = df[

    (df.debt_to_equity == 0)

    &

    (df.return_on_equity_pct > 12)

]

turnaround = df[

    (df.revenue_cagr_3yr > 10)

    &

    (df.free_cash_flow_cr > 0)

]

print("=" * 70)

print("Quality Compounder :", len(quality))

print("Value Pick :", len(value))

print("Growth :", len(growth))

print("Dividend :", len(dividend))

print("Debt Free :", len(bluechip))

print("Turnaround :", len(turnaround))


with pd.ExcelWriter(
    "output/screener_output.xlsx"
) as writer:

    quality.to_excel(
        writer,
        sheet_name="Quality Compounder",
        index=False
    )

    value.to_excel(
        writer,
        sheet_name="Value Pick",
        index=False
    )

    growth.to_excel(
        writer,
        sheet_name="Growth Accelerator",
        index=False
    )

    dividend.to_excel(
        writer,
        sheet_name="Dividend Champion",
        index=False
    )

    bluechip.to_excel(
        writer,
        sheet_name="Debt Free Blue Chip",
        index=False
    )

    turnaround.to_excel(
        writer,
        sheet_name="Turnaround Watch",
        index=False
    )

print("Excel Generated Successfully")

