import streamlit as st

def render():

    st.title("🏢 Company Profile")

    st.text_input("Search Company")

    st.info("Company Profile screen will be implemented on Day 23.")

    col1, col2 = st.columns(2)

    with col1:
        st.empty()

    with col2:
        st.empty()