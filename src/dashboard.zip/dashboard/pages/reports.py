import streamlit as st

def render():

    st.title("📄 Annual Reports")

    st.info("Annual Reports dashboard coming on Day 25.")

    st.empty()