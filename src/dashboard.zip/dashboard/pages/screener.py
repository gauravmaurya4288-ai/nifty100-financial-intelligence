import streamlit as st

def render():

    st.title("🔍 Stock Screener")

    st.info("Interactive Screener coming on Day 24.")

    st.sidebar.subheader("Filters")

    st.empty()