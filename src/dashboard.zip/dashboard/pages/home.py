import streamlit as st

def render():

    st.title("🏠 Home Dashboard")

    st.info("Home Dashboard will be implemented on Day 23.")

    c1, c2, c3 = st.columns(3)

    c1.metric("Companies", "--")
    c2.metric("Average ROE", "--")
    c3.metric("Median P/E", "--")

    st.divider()

    st.subheader("Sector Overview")

    st.empty()

    st.subheader("Top Companies")

    st.empty()