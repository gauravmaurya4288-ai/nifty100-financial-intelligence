import streamlit as st
import pandas as pd
from pathlib import Path

# -------------------------------------------------
# Page Configuration
# -------------------------------------------------

st.set_page_config(
    page_title="Cluster Analytics",
    page_icon="📊",
    layout="wide"
)

# -------------------------------------------------
# Paths
# -------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[2]

OUTPUT_DIR = PROJECT_ROOT / "output"
REPORT_DIR = PROJECT_ROOT / "reports"

# -------------------------------------------------
# Load Data
# -------------------------------------------------

@st.cache_data
def load_data():

    insights = pd.read_csv(
        OUTPUT_DIR / "cluster_insights.csv"
    )

    labels = pd.read_csv(
        OUTPUT_DIR / "cluster_labels.csv"
    )

    return insights, labels


insights, labels = load_data()

# -------------------------------------------------
# Header
# -------------------------------------------------

st.title("📊 Cluster Analytics Dashboard")

st.markdown(
    """
    Explore the clustering results of Nifty 100 companies based on
    financial performance, profitability, leverage and growth.
    """
)

st.divider()

# -------------------------------------------------
# KPI Cards
# -------------------------------------------------

total_companies = labels["company_id"].nunique()

total_clusters = insights["cluster_id"].nunique()

largest = insights.loc[
    insights["companies"].idxmax()
]

c1, c2, c3 = st.columns(3)

with c1:
    st.metric(
        "Companies",
        total_companies
    )

with c2:
    st.metric(
        "Clusters",
        total_clusters
    )

with c3:
    st.metric(
        "Largest Cluster",
        largest["cluster_name"]
    )

st.caption(
    f'{largest["companies"]} Companies'
)

st.divider()

# =====================================================
# Cluster Insights
# =====================================================

st.subheader("📋 Cluster Insights")

display_df = insights.copy()

display_df = display_df.rename(
    columns={
        "cluster_id": "Cluster ID",
        "cluster_name": "Cluster Name",
        "companies": "Companies",
        "return_on_equity_pct": "ROE (%)",
        "debt_to_equity": "Debt/Equity",
        "revenue_cagr_5yr": "Revenue CAGR (%)",
        "net_cash_flow": "Net Cash Flow",
        "operating_profit_margin_pct": "OPM (%)",
        "investment_profile": "Investment Profile",
    }
)

st.dataframe(
    display_df,
    use_container_width=True,
    hide_index=True,
)

# =====================================================
# Quick Summary
# =====================================================

st.subheader("📈 Cluster Overview")

col1, col2 = st.columns(2)

with col1:

    st.success(
        f"Highest ROE : "
        f"{display_df.loc[display_df['ROE (%)'].idxmax(),'Cluster Name']}"
    )

    st.info(
        f"Highest Revenue Growth : "
        f"{display_df.loc[display_df['Revenue CAGR (%)'].idxmax(),'Cluster Name']}"
    )

with col2:

    st.warning(
        f"Highest Debt : "
        f"{display_df.loc[display_df['Debt/Equity'].idxmax(),'Cluster Name']}"
    )

    st.success(
        f"Highest Cash Flow : "
        f"{display_df.loc[display_df['Net Cash Flow'].idxmax(),'Cluster Name']}"
    )

st.divider()

import plotly.express as px

# =====================================================
# Cluster Distribution
# =====================================================

st.subheader("📊 Companies per Cluster")

fig = px.bar(
    insights,
    x="cluster_name",
    y="companies",
    color="cluster_name",
    text="companies",
    title="Company Distribution Across Clusters",
)

fig.update_layout(
    xaxis_title="Cluster",
    yaxis_title="Companies",
    showlegend=False,
)

fig.update_traces(textposition="outside")

st.plotly_chart(
    fig,
    use_container_width=True
)

# =====================================================
# Financial Metrics Comparison
# =====================================================

st.subheader("📈 Financial Metrics Comparison")

metrics = [
    "return_on_equity_pct",
    "debt_to_equity",
    "revenue_cagr_5yr",
    "operating_profit_margin_pct",
]

selected_metric = st.selectbox(
    "Select Financial Metric",
    metrics,
    format_func=lambda x: x.replace("_", " ").title(),
)

fig = px.bar(
    insights,
    x="cluster_name",
    y=selected_metric,
    color="cluster_name",
    text=selected_metric,
)

fig.update_layout(
    showlegend=False,
    xaxis_title="Cluster",
    yaxis_title=selected_metric.replace("_", " ").title(),
)

st.plotly_chart(
    fig,
    use_container_width=True
)

# =====================================================
# Bubble Chart
# =====================================================

st.subheader("🫧 Cluster Risk vs Profitability")

fig = px.scatter(
    insights,
    x="debt_to_equity",
    y="return_on_equity_pct",
    size="companies",
    color="cluster_name",
    hover_name="cluster_name",
    size_max=70,
)

fig.update_layout(
    xaxis_title="Debt to Equity",
    yaxis_title="Return on Equity (%)",
)

st.plotly_chart(
    fig,
    use_container_width=True
)

# =====================================================
# Radar Chart
# =====================================================

st.subheader("🎯 Cluster Financial Profile")

cluster = st.selectbox(
    "Choose Cluster",
    insights["cluster_name"]
)

row = insights[
    insights["cluster_name"] == cluster
].iloc[0]

categories = [
    "ROE",
    "Debt",
    "Revenue CAGR",
    "Cash Flow",
    "OPM",
]

values = [
    row["return_on_equity_pct"],
    row["debt_to_equity"],
    row["revenue_cagr_5yr"],
    row["net_cash_flow"] / 1000,
    row["operating_profit_margin_pct"],
]

fig = px.line_polar(
    r=values,
    theta=categories,
    line_close=True,
)

fig.update_traces(fill="toself")

st.plotly_chart(
    fig,
    use_container_width=True
)

st.subheader("🎯 Filter Companies by Cluster")

cluster_options = ["All"] + list(insights["cluster_name"])

selected_cluster = st.selectbox(
    "Select Cluster",
    cluster_options
)

cluster_map = dict(
    zip(
        insights["cluster_name"],
        insights["cluster_id"]
    )
)

filtered_df = company_df.copy()

if selected_cluster != "All":

    filtered_df = filtered_df[
        filtered_df["cluster_id"] ==
        cluster_map[selected_cluster]
    ]

st.dataframe(
    filtered_df[
        [
            "company_name",
            "broad_sector",
            "cluster_id"
        ]
    ],
    use_container_width=True,
    hide_index=True
)

st.subheader("🔍 Company Search")

company = st.selectbox(
    "Choose Company",
    sorted(company_df["company_name"].dropna())
)

row = company_df[
    company_df["company_name"] == company
].iloc[0]

cluster_name = insights.loc[
    insights["cluster_id"] == row["cluster_id"],
    "cluster_name"
].values[0]

c1, c2, c3 = st.columns(3)

with c1:
    st.metric("Company", row["company_name"])

with c2:
    st.metric("Sector", row["broad_sector"])

with c3:
    st.metric("Cluster", cluster_name)

    st.subheader("📥 Export Results")

csv = insights.to_csv(index=False).encode("utf-8")

st.download_button(
    label="Download Cluster Insights",
    data=csv,
    file_name="cluster_insights.csv",
    mime="text/csv",
)

st.markdown("""
<style>
.metric-card{
background:#1e293b;
padding:20px;
border-radius:15px;
border-left:6px solid #3b82f6;
box-shadow:0 3px 12px rgba(0,0,0,.25);
margin-bottom:15px;
}
.metric-title{
color:#94a3b8;
font-size:15px;
}
.metric-value{
font-size:32px;
font-weight:bold;
color:white;
}
</style>
""", unsafe_allow_html=True)

import plotly.express as px

treemap = px.treemap(
    company_df,
    path=["broad_sector","company_name"],
    color="cluster_id",
    title="Sector Distribution"
)

st.plotly_chart(
    treemap,
    use_container_width=True
)

health = insights.copy()

health["health_score"] = (
    health["return_on_equity_pct"]*0.35
    + health["revenue_cagr_5yr"]*0.25
    + health["operating_profit_margin_pct"]*0.25
    - health["debt_to_equity"]*5
)

st.subheader("⭐ Cluster Health Score")

st.dataframe(
    health[
        ["cluster_name","health_score"]
    ].sort_values(
        "health_score",
        ascending=False
    ),
    hide_index=True
)

st.subheader("⚖ Compare Companies")

col1,col2=st.columns(2)

with col1:
    c1=st.selectbox(
        "Company A",
        company_df.company_name.unique()
    )

with col2:
    c2=st.selectbox(
        "Company B",
        company_df.company_name.unique(),
        index=1
    )

compare=company_df[
    company_df.company_name.isin([c1,c2])
]

st.dataframe(compare,use_container_width=True)

best=health.sort_values(
    "health_score",
    ascending=False
).iloc[0]

st.subheader("🧠 AI Investment Insight")

st.success(f"""
Based on profitability,
growth,
operating margin
and leverage,

**{best['cluster_name']}**
currently appears to be
the strongest investment cluster.
""")

st.metric(
    "🏆 Best Performing Cluster",
    best["cluster_name"],
    f"{best['health_score']:.2f}"
)

st.subheader("Dashboard Statistics")

st.write(f"Total Companies : {total_companies}")

st.write(f"Clusters : {total_clusters}")

st.write(
    f"Average ROE : {insights['return_on_equity_pct'].mean():.2f}%"
)

st.write(
    f"Average Debt : {insights['debt_to_equity'].mean():.2f}"
)

csv=company_df.to_csv(index=False)

st.download_button(
    "⬇ Download Company Data",
    csv,
    "company_clusters.csv",
    "text/csv"
)
