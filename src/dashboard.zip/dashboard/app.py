import sys
from pathlib import Path

import streamlit as st

# ==========================================================
# ADD PROJECT PATH
# ==========================================================

CURRENT_DIR = Path(__file__).parent

sys.path.append(str(CURRENT_DIR))

# ==========================================================
# IMPORT PAGES
# ==========================================================

from pages import (
    home,
    profile,
    screener,
    peers,
    trends,
    sectors,
    capital,
    reports,
)

# ==========================================================
# PAGE CONFIG
# ==========================================================

st.set_page_config(
    page_title="Nifty 100 Analytics",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ==========================================================
# SIDEBAR
# ==========================================================

st.sidebar.title("📈 Nifty100 Analytics")

st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigation",
    (
        "🏠 Home",
        "🏢 Company Profile",
        "🔍 Screener",
        "🤝 Peer Comparison",
        "📊 Trend Analysis",
        "🏭 Sector Analysis",
        "💰 Capital Allocation",
        "📄 Annual Reports",
    ),
)

st.sidebar.markdown("---")

st.sidebar.success("Sprint 4 Dashboard")

st.sidebar.caption("Version 1.0")

# ==========================================================
# HEADER
# ==========================================================

st.title("📈 Nifty100 Financial Intelligence Platform")

st.caption(
    "Advanced Financial Analytics • Stock Screener • Peer Analysis • Portfolio Intelligence"
)

st.divider()

# ==========================================================
# PAGE ROUTER
# ==========================================================

PAGE_MAP = {
    "🏠 Home": home.render,
    "🏢 Company Profile": profile.render,
    "🔍 Screener": screener.render,
    "🤝 Peer Comparison": peers.render,
    "📊 Trend Analysis": trends.render,
    "🏭 Sector Analysis": sectors.render,
    "💰 Capital Allocation": capital.render,
    "📄 Annual Reports": reports.render,
}

PAGE_MAP[page]()

# ==========================================================
# FOOTER
# ==========================================================

st.divider()

st.caption(
    "Nifty100 Financial Intelligence Platform | Sprint 4 | Day 22"
)